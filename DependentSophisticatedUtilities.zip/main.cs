using System;

class MainClass {
  public static void Main (string[] args) {
    Console.Write("Skriv ett tal mellan 1 och 100: ");
    int startTal = int.Parse(Console.ReadLine());
    for(int i=startTal; i<=101; i++)
    {
      Console.WriteLine(i);
    }
  }
}