using System;

class MainClass {
  public static void Main (string[] args) {
    Console.Write("Skriv ett tal mellan 1 och 101: ");
    double startTal = int.Parse(Console.ReadLine());
    for(double i=startTal; i<=101; i++)
    {
      Console.WriteLine(i);
    }
    Console.Write("Medelvärdet är: ");
      Console.WriteLine((startTal + 101) / 2);
  }
}